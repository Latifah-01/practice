package com.example.tc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
